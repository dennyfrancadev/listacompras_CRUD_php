
    Desenvolvedor: Denny França                                                          
    Github: https://github.com/dennyfrancadev                                              
                                                                                   


Um sistema web em PHP de listas de compras html, bootstrap e php (PDO).

OBS: Para a criação do banco de dados, usuário e tabela rode o arquivo crud.sql ou inserir no PHPMyAdmin.