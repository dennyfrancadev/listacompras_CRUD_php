<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <title>Alteração do Item</title>
  </head>
  <body>
    <?php
        /*include "conexao.php";
        $id = $_GET['id'] ?? '';
        $sql = "SELECT * FROM lista_marco WHERE cod_produto = $id";

        $dados = mysqli_query($conn, $sql);
        //$linha = mysqli_fetch_assoc($dados);
        */
        
        $produto = $_GET['id'];
        $quantidade = $_GET['quant'];

       // echo "<script>alert('{$produto}');</script>";
        //echo "<script>alert('{$quantidade}');</script>";

    ?>
      <script>   

if(typeof window.history.pushState == 'function') {

    window.history.pushState({}, "Hide", '<?php echo $_SERVER['PHP_SELF'];?>');

}

</script>
    <div class="container"><!--container-->
        <div class="row"><!--row-->
            <div clas="col"><!--col-->
                <h1>Lista</h1>
                <form action="edit_script.php" method="POST">
                    <div class="form-group">
                        <label for="produto">Produto</label>
                        <input type="texto" class="form-control" name="produto" required value="<?php echo "$produto"; ?>">
                    </div>
                    <div class="form-group">
                        <label for="quantidade">Quantidade</label>
                        <input type="texto" class="form-control" name="quantidade" required value="<?php echo "$quantidade"; ?>">
                    </div>
                    <div class="form-group">
                        <input type="submit" class="btn btn-success" value="Salvar Alterações">
                        <input type="hidden" name="id" value="<?php echo $linha['cod_produto']?>">
                    </div>
                </form>
                <a href="index.php" class="btn btn-info">Voltar para o Inicio</a>
            </div><!--col-->
        </div><!--row-->
    </div><!--container-->
    

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
    -->
  </body>
</html>