<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <title>Lista</title>
  </head>
  <body>

    <?php
      
            $pesquisa = $_POST['busca'] ?? '';


            include "conexao.php";

            $sql = "SELECT * FROM lista_marco WHERE produto LIKE '%$pesquisa%'"  ;
            $dados = mysqli_query($conn, $sql);
    ?>
   
    <div class="container"><!--container-->
        <div class="row"><!--row-->
            <div clas="col"><!--col-->
                <h1>Pesquisar</h1>
                <nav class="navbar navbar-light bg-light">
                    <div class="container-fluid">
                     <form class="d-flex" action="pesquisa.php" method="POST">
                    <input class="form-control me-2" type="search" placeholder="Produto" aria-label="Search" name="busca" autofocus>
                    <button class="btn btn-outline-success" type="submit">Pesquisar</button>
                    </form>
                     </div>
                </nav>
                
                <table class="table table-hover">

                    <thead>
                        <tr>
                            <th scope="col">Produto</th>
                            <th scope="col">Quantdade</th>
                            <th scope="col">Funções</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php

                    while ($linha = mysqli_fetch_assoc($dados)) {
                            //$cod_produto = $linha['cod_produto'];
                            $cod_produto = $linha['produto'];
                            $quantidade = $linha['quantidade'];

                            echo "<tr> 
                                    <th> $cod_produto</th>
                                    <td> $quantidade</td>
                                    <td>
                                        <a href='cadastro_edit.php?id=$cod_produto&quant=$quantidade 'class='btn btn-success'?>Editar</a>
                                        <a href='#' class='btn btn-danger' data-toggle='modal' data-target='#confirma'>Excluir</a>
                                    </td>                            
                                </tr>";
                
                    }
                    ?>
                        

                    </tbody>
                    </table>
                
                <a href="index.php" class="btn btn-info">Voltar para o Inicio</a>
            </div><!--col-->
        </div><!--row-->
    </div><!--container-->
                    <!-- Modal -->
<div class="modal fade" id="confirma" tabindex="-1" role='dialog' aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role='document'>
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Confirmação de Exclusão</h5>
        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span arial-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Deseja realmente excluir?</p>
        <p id="nome_produto">Nome do produto</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Não</button>
        <button type="button" class="btn btn-danger">Sim</button>
      </div>
    </div>
  </div>
</div>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
    -->
  </body>
</html>